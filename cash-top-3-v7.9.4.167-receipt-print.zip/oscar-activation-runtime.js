/* Cash Top 3 Activation Runtime v1
 * Offline-first portable encrypted activation files + Turso direct helpers.
 * Browser-side encryption protects credentials from casual inspection only;
 * real security still depends on Turso token permissions and device security.
 */
(() => {
  'use strict';
  const APP_TAG='OSCAR_ACCOUNTING_ACTIVATION_V1';
  const RUNTIME_KEY='oscar_activation_runtime_v1';
  const MASTER_KEY='oscar_master_runtime_v1';
  const LOCAL_DB_ACCESS_KEY='oscar_local_db_access_v1';
  const VERIFIED_KEY='oscar_verified_files_v1';
  const enc=new TextEncoder(), dec=new TextDecoder();
  const safe=v=>String(v??'').trim();
  const clone=v=>JSON.parse(JSON.stringify(v));
  const b64=u8=>btoa(String.fromCharCode(...u8));
  const unb64=s=>Uint8Array.from(atob(String(s||'')),c=>c.charCodeAt(0));
  const K=['AM','_8Q','2x','!m','7Z','b4','_r','9P','@k','5N'].join('');
  const mask=s=>enc.encode(String(s));
  function xor(bytes,key){const out=new Uint8Array(bytes.length),m=mask(key);for(let i=0;i<bytes.length;i++)out[i]=bytes[i]^m[i%m.length];return out}
  const wrapText=s=>b64(xor(enc.encode(String(s||'')),K));
  const unwrapText=s=>dec.decode(xor(unb64(s),K));

  async function derive(password,salt,iterations=220000){
    const material=await crypto.subtle.importKey('raw',enc.encode(String(password)),'PBKDF2',false,['deriveKey']);
    return crypto.subtle.deriveKey({name:'PBKDF2',salt,iterations,hash:'SHA-256'},material,{name:'AES-GCM',length:256},false,['encrypt','decrypt']);
  }
  async function aesEncrypt(text,password,saltBytes=null){
    const salt=saltBytes||crypto.getRandomValues(new Uint8Array(16)),iv=crypto.getRandomValues(new Uint8Array(12)),key=await derive(password,salt);
    const cipher=new Uint8Array(await crypto.subtle.encrypt({name:'AES-GCM',iv},key,enc.encode(String(text))));
    return {salt,iv,cipher};
  }
  async function aesDecrypt(cipher,password,salt,iv){
    const key=await derive(password,salt);return dec.decode(await crypto.subtle.decrypt({name:'AES-GCM',iv},key,cipher));
  }

  async function sealObject(value,secret){
    const pass=safe(secret);if(!pass)throw new Error('مفتاح الحماية غير متوفر.');
    const salt=crypto.getRandomValues(new Uint8Array(16)),iv=crypto.getRandomValues(new Uint8Array(12)),key=await derive(pass,salt,240000);
    const cipher=new Uint8Array(await crypto.subtle.encrypt({name:'AES-GCM',iv},key,enc.encode(JSON.stringify(value))));
    const out=new Uint8Array(28+cipher.length);out.set(salt,0);out.set(iv,16);out.set(cipher,28);return 'AMV1.'+b64(out);
  }
  async function openObject(value,secret){
    const text=safe(value);if(!text.startsWith('AMV1.'))throw new Error('بيانات الخزنة غير صالحة.');
    const raw=unb64(text.slice(5));if(raw.length<45)throw new Error('بيانات الخزنة تالفة.');
    const key=await derive(safe(secret),raw.slice(0,16),240000);
    const plain=await crypto.subtle.decrypt({name:'AES-GCM',iv:raw.slice(16,28)},key,raw.slice(28));return JSON.parse(dec.decode(plain));
  }

  function tursoTable(db){return safe(db?.table||'oscar_rtdb').replace(/[^a-zA-Z0-9_]/g,'')||'oscar_rtdb'}
  function tursoPipelineUrl(db){const url=safe(db?.databaseURL);if(!url)throw new Error('رابط قاعدة البيانات غير موجود.');if(!/^(?:libsql|https?):\/\//i.test(url))throw new Error('رابط قاعدة البيانات غير صالح.');return url.replace(/^libsql:\/\//i,'https://').replace(/\/+$/,'')+'/v2/pipeline'}
  function arg(value){if(value==null)return{type:'null'};if(typeof value==='number'&&Number.isInteger(value))return{type:'integer',value:String(value)};if(typeof value==='number')return{type:'float',value:String(value)};return{type:'text',value:String(value)}}
  function cell(c){if(!c||c.type==='null')return null;if(c.type==='integer'||c.type==='float'){const n=Number(c.value);return Number.isFinite(n)?n:c.value}return c.value}
  function rows(result){const names=(result?.cols||[]).map(c=>c.name);return(result?.rows||[]).map(r=>Object.fromEntries(r.map((c,i)=>[names[i],cell(c)])))}
  async function pipeline(db,statements,timeout=26000){
    const token=safe(db?.authToken);if(!token)throw new Error('توكن قاعدة البيانات غير موجود.');
    const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),timeout);
    try{
      const response=await fetch(tursoPipelineUrl(db),{method:'POST',headers:{Authorization:`Bearer ${token}`,'Content-Type':'application/json',Accept:'application/json'},body:JSON.stringify({requests:[...statements.map(st=>({type:'execute',stmt:{sql:st.sql,args:(st.args||[]).map(arg)}})),{type:'close'}]}),signal:controller.signal,cache:'no-store'});
      const text=await response.text();if(!response.ok)throw new Error(`Turso HTTP ${response.status}: ${text.slice(0,220)}`);
      let data;try{data=JSON.parse(text)}catch(_){throw new Error('استجابة قاعدة البيانات غير صالحة.');}
      return statements.map((_,i)=>{const item=data?.results?.[i];if(!item||item.type!=='ok')throw new Error(`Turso SQL: ${item?.error?.message||item?.error||'UNKNOWN'}`);return item.response?.result||{cols:[],rows:[],affected_row_count:0}});
    }catch(error){if(error?.name==='AbortError')throw new Error('انتهت مهلة الاتصال بقاعدة البيانات.');throw error}finally{clearTimeout(timer)}
  }
  async function ensure(db){const table=tursoTable(db);await pipeline(db,[{sql:`CREATE TABLE IF NOT EXISTS ${table} (path TEXT PRIMARY KEY,payload TEXT,deleted INTEGER NOT NULL DEFAULT 0,updated_at INTEGER NOT NULL)`,args:[]}]);return true}
  function normalizePath(path){return safe(path).replace(/\.json(?:\?.*)?$/i,'').replace(/^\/+|\/+$/g,'').replace(/\/{2,}/g,'/')}
  function parsePayload(v){if(v==null)return null;if(typeof v!=='string')return v;try{return JSON.parse(v)}catch(_){return v}}
  async function readExact(db,path,{ensureSchema=false}={}){if(ensureSchema)await ensure(db);const table=tursoTable(db),p=normalizePath(path);const[r]=await pipeline(db,[{sql:`SELECT payload,deleted,updated_at FROM ${table} WHERE path=? LIMIT 1`,args:[p]}]);const row=rows(r)[0];if(!row)return undefined;return Number(row.deleted)===1?null:parsePayload(row.payload)}
  async function readExactRow(db,path,{ensureSchema=false}={}){if(ensureSchema)await ensure(db);const table=tursoTable(db),p=normalizePath(path);const[r]=await pipeline(db,[{sql:`SELECT path,payload,deleted,updated_at FROM ${table} WHERE path=? LIMIT 1`,args:[p]}]);const row=rows(r)[0];return row?{...row,payload:parsePayload(row.payload)}:undefined}
  async function listPrefix(db,path,{ensureSchema=false}={}){if(ensureSchema)await ensure(db);const table=tursoTable(db),p=normalizePath(path),hi=p+'\uffff';const[r]=await pipeline(db,[{sql:`SELECT path,payload,deleted,updated_at FROM ${table} WHERE path>=? AND path<? ORDER BY path`,args:[p,hi]}],60000);return rows(r).map(x=>({...x,payload:parsePayload(x.payload)}))}
  async function writeExact(db,path,value,updatedAt=Date.now(),deleted=false){await ensure(db);const table=tursoTable(db),p=normalizePath(path);await pipeline(db,[{sql:`INSERT INTO ${table}(path,payload,deleted,updated_at) VALUES(?,?,?,?) ON CONFLICT(path) DO UPDATE SET payload=excluded.payload,deleted=excluded.deleted,updated_at=excluded.updated_at`,args:[p,JSON.stringify(value),deleted?1:0,Number(updatedAt)||Date.now()]}]);return true}
  async function deletePrefix(db,path){await ensure(db);const table=tursoTable(db),p=normalizePath(path),like=p+'/%';await pipeline(db,[{sql:`DELETE FROM ${table} WHERE path=? OR path LIKE ?`,args:[p,like]}],60000);return true}
  const tursoDirect=Object.freeze({table:tursoTable,pipeline,rows,ensure,readExact,readExactRow,listPrefix,writeExact,deletePrefix,normalizePath});

  async function packOpaque(payload){
    const activationKey=safe(payload.activationKey);if(!activationKey)throw new Error('ملف التفعيل يحتاج مفتاح شركة.');
    const keySalt=crypto.getRandomValues(new Uint8Array(16)),wrapped=await aesEncrypt(activationKey,K,keySalt),keyBlob=new Uint8Array(12+wrapped.cipher.length);keyBlob.set(wrapped.iv,0);keyBlob.set(wrapped.cipher,12);
    const payloadSalt=crypto.getRandomValues(new Uint8Array(16)),payloadIv=crypto.getRandomValues(new Uint8Array(12)),payloadKey=await derive(activationKey,payloadSalt);
    const cipher=new Uint8Array(await crypto.subtle.encrypt({name:'AES-GCM',iv:payloadIv},payloadKey,enc.encode(JSON.stringify({...payload,app:APP_TAG}))));
    const out=new Uint8Array(1+16+2+keyBlob.length+16+12+cipher.length);let o=0;out[o++]=0x6d;out.set(keySalt,o);o+=16;out[o++]=(keyBlob.length>>8)&255;out[o++]=keyBlob.length&255;out.set(keyBlob,o);o+=keyBlob.length;out.set(payloadSalt,o);o+=16;out.set(payloadIv,o);o+=12;out.set(cipher,o);return b64(out);
  }
  async function unpackOpaque(text){
    let raw;try{raw=unb64(String(text||'').replace(/\s+/g,''))}catch(_){throw new Error('ملف التفعيل غير صالح.');}
    if(raw.length<90||raw[0]!==0x6d)throw new Error('ملف التفعيل غير صالح.');let o=1;const keySalt=raw.slice(o,o+16);o+=16;const len=(raw[o++]<<8)|raw[o++];if(len<29||o+len+44>raw.length)throw new Error('ملف التفعيل تالف.');const keyBlob=raw.slice(o,o+len);o+=len;
    let activationKey='';try{activationKey=await aesDecrypt(keyBlob.slice(12),K,keySalt,keyBlob.slice(0,12))}catch(_){throw new Error('تعذر التحقق من ملف التفعيل.');}
    const payloadSalt=raw.slice(o,o+16);o+=16;const payloadIv=raw.slice(o,o+12);o+=12;const cipher=raw.slice(o);try{const key=await derive(activationKey,payloadSalt),plain=await crypto.subtle.decrypt({name:'AES-GCM',iv:payloadIv},key,cipher),payload=JSON.parse(dec.decode(plain));if(payload?.app!==APP_TAG||safe(payload.activationKey)!==safe(activationKey))throw new Error();return payload}catch(_){throw new Error('فشل فك ملف التفعيل أو تم العبث به.');}
  }
  async function makeFile(payload){const value={...clone(payload),fileId:payload.fileId||(crypto.randomUUID?crypto.randomUUID():`${Date.now()}_${Math.random()}`),app:APP_TAG};return{value,opaque:await packOpaque(value)}}
  function activationFileName(payload,fileName){return (fileName||`${payload.companyName||'Oscar'}-login.mzauth`).replace(/[\\/:*?"<>|]+/g,'_').replace(/\.(?:mzauth|ctauth)$/i,'')+'.mzauth'}
  async function prepareActivationDownload(payload,fileName){const made=await makeFile(payload),name=activationFileName(payload,fileName),blob=new Blob([made.opaque],{type:'application/octet-stream'}),url=URL.createObjectURL(blob);return{payload:made.value,made,name,url,createdAt:Date.now()}}
  function triggerPreparedActivationDownload(prepared){if(!prepared?.url)throw new Error('ملف الدخول غير جاهز للتنزيل.');const a=document.createElement('a');a.href=prepared.url;a.download=prepared.name||'Oscar-login.mzauth';a.rel='noopener';document.body.appendChild(a);a.click();a.remove();setTimeout(()=>{try{URL.revokeObjectURL(prepared.url)}catch(_){ }prepared.url=''},60000);return prepared.made}
  async function downloadActivationFile(payload,fileName){const prepared=await prepareActivationDownload(payload,fileName);triggerPreparedActivationDownload(prepared);return prepared.made}
  async function copyActivationFile(payload){const made=await makeFile(payload);try{await navigator.clipboard.writeText(made.opaque)}catch(_){const field=document.createElement('textarea');field.value=made.opaque;field.style.cssText='position:fixed;inset:20px;z-index:2147483647';document.body.appendChild(field);field.select();const copied=document.execCommand('copy');field.remove();if(!copied)throw Error('تعذر النسخ؛ استخدم تنزيل ملف الدخول.')}return made}
  const activationFileTextCache=new WeakMap(),activationFilePayloadCache=new WeakMap();
  async function readActivationFileText(file){
    if(!file)throw new Error('اختر ملف التفعيل أولاً.');
    if(activationFileTextCache.has(file))return activationFileTextCache.get(file);
    let lastError=null,text='';
    // FileReader is more reliable with Android/Samsung document providers when the selected file is read immediately.
    try{text=await new Promise((resolve,reject)=>{const r=new FileReader();r.onerror=()=>reject(r.error||new Error('تعذر قراءة الملف.'));r.onabort=()=>reject(new Error('تم إلغاء قراءة الملف.'));r.onload=()=>resolve(String(r.result||''));r.readAsText(file)});}catch(e){lastError=e}
    if(!text){try{text=dec.decode(new Uint8Array(await file.arrayBuffer()))}catch(e){lastError=e}}
    if(!text){try{text=await file.text()}catch(e){lastError=e}}
    text=String(text||'').trim();
    if(!text){const raw=String(lastError?.message||lastError||'');if(/requested file|directory could not be found|notfound|not found/i.test(raw))throw new Error('تعذر الوصول إلى ملف التفعيل بعد اختياره من مدير الملفات. اختر الملف مرة أخرى من مجلد التنزيلات أو الملفات، وسيتم نسخه إلى الذاكرة فور اختياره.');throw new Error('تعذر قراءة ملف التفعيل أو أن الملف فارغ.');}
    activationFileTextCache.set(file,text);return text;
  }
  async function primeActivationFile(file){
    if(!file)return null;if(!/\.mzauth$/i.test(file.name||''))throw new Error('امتداد الملف غير معتمد. استخدم ملف .mzauth');
    const text=await readActivationFileText(file),payload=await unpackOpaque(text);activationFilePayloadCache.set(file,payload);return payload;
  }
  async function parseActivationFile(file){if(!file)throw new Error('اختر ملف التفعيل أولاً.');if(!/\.mzauth$/i.test(file.name||''))throw new Error('امتداد الملف غير معتمد. استخدم ملف .mzauth');const p=activationFilePayloadCache.get(file)||await primeActivationFile(file);if(p.expiresAt&&Date.now()>=new Date(p.expiresAt).getTime())throw new Error('انتهت صلاحية ملف التفعيل.');return p}

  const scopedDbKey=id=>`${LOCAL_DB_ACCESS_KEY}::${encodeURIComponent(safe(id)||'current')}`;
  function saveDatabaseAccess(db,meta={}){const identity=safe(meta.companyId||meta.tenantId||readRuntime()?.companyId),cfg={databaseURL:safe(db?.databaseURL),authToken:safe(db?.authToken),table:safe(db?.table||'oscar_rtdb'),companyId:identity,tenantId:identity,savedAt:Date.now()};if(!cfg.databaseURL||!cfg.authToken)throw new Error('بيانات قاعدة الشركة غير مكتملة.');const wrapped=wrapText(JSON.stringify(cfg));localStorage.setItem(LOCAL_DB_ACCESS_KEY,wrapped);if(identity)localStorage.setItem(scopedDbKey(identity),wrapped);return cfg}
  function readDatabaseAccess(identity=''){
    const wanted=safe(identity||readRuntime()?.companyId);
    // Company database credentials are STRICTLY tenant scoped. Never borrow the
    // last opened company's generic credentials for a different/new company.
    if(wanted){
      try{
        const raw=localStorage.getItem(scopedDbKey(wanted));
        const cfg=raw?JSON.parse(unwrapText(raw)):null;
        if(cfg?.databaseURL&&cfg?.authToken&&safe(cfg.companyId)===wanted)return cfg;
      }catch(_){ }
      // Compatibility: an old generic record may be used only when it explicitly
      // belongs to the exact same company. Blank/unscoped records are rejected.
      try{
        const raw=localStorage.getItem(LOCAL_DB_ACCESS_KEY);
        const cfg=raw?JSON.parse(unwrapText(raw)):null;
        if(cfg?.databaseURL&&cfg?.authToken&&safe(cfg.companyId)===wanted){
          try{localStorage.setItem(scopedDbKey(wanted),raw)}catch(_){ }
          return cfg;
        }
      }catch(_){ }
      return null;
    }
    try{
      const raw=localStorage.getItem(LOCAL_DB_ACCESS_KEY),cfg=raw?JSON.parse(unwrapText(raw)):null;
      return cfg?.databaseURL&&cfg?.authToken?cfg:null;
    }catch(_){return null}
  }
  function activatePayload(payload){
    if(!payload||payload.app!==APP_TAG)throw new Error('ملف التفعيل غير صالح.');
    const companyId=safe(payload.companyId||payload.tenantId),companyKey=safe(payload.companyKey||payload.activationKey);
    if(!companyId||!companyKey)throw new Error('ملف الشركة غير مكتمل.');
    const cfg=payload.database||{},customerCfg=payload.customerDatabase||{},aiCfg=payload.ai||{},runtime={activationKey:payload.activationKey,fileId:payload.fileId,type:payload.type,companyId,tenantId:companyId,companyKey,companyName:payload.companyName,account:payload.account||null,permissions:payload.permissions||payload.account?.permissions||[],status:payload.status||'active',plan:payload.plan||'lifetime',expiresAt:payload.expiresAt||'',database:{databaseURL:safe(cfg.databaseURL),authToken:safe(cfg.authToken),table:safe(cfg.table||'oscar_rtdb')},customerDatabase:{databaseURL:safe(customerCfg.databaseURL||cfg.databaseURL),authToken:safe(customerCfg.authToken),table:safe(customerCfg.table||cfg.table||'oscar_rtdb')},trialProfile:clone(payload.trialProfile||{}),trialLimits:clone(payload.trialLimits||{}),ai:{provider:safe(aiCfg.provider||'openrouter')||'openrouter',apiKey:safe(aiCfg.apiKey),model:safe(aiCfg.model||'google/gemini-2.5-flash:free')||'google/gemini-2.5-flash:free'},rootPath:payload.rootPath||'oscar/companies',isTrialLink:!!payload.isTrialLink,appBaseUrl:normalizeAppUrl(payload.appBaseUrl),activatedAt:Date.now()};
    localStorage.setItem(RUNTIME_KEY,wrapText(JSON.stringify(runtime)));
    if(runtime.database.databaseURL&&runtime.database.authToken)saveDatabaseAccess(runtime.database,{companyId});
    window.dispatchEvent(new CustomEvent('oscar:activation-loaded',{detail:{...runtime,database:{...runtime.database,authToken:''},customerDatabase:{...runtime.customerDatabase,authToken:runtime.customerDatabase?.authToken?'***':''},ai:{...runtime.ai,apiKey:runtime.ai.apiKey?'***':''}}}));
    return runtime
  }
  function readRuntime(){try{const raw=localStorage.getItem(RUNTIME_KEY);return raw?JSON.parse(unwrapText(raw)):null}catch(_){return null}}
  function clearRuntime(){window.dispatchEvent(new Event('ct:logout'));localStorage.removeItem(RUNTIME_KEY)}
  function saveMasterConfig(cfg){const aiInput=cfg.ai||{},master={database:{databaseURL:safe(cfg.databaseURL),authToken:safe(cfg.authToken),table:safe(cfg.table||'oscar_rtdb')},ai:{provider:safe(cfg.aiProvider||aiInput.provider||'openrouter')||'openrouter',apiKey:safe(cfg.aiApiKey||aiInput.apiKey),model:safe(cfg.aiModel||aiInput.model||'google/gemini-2.5-flash:free')||'google/gemini-2.5-flash:free'},adminRootPath:cfg.adminRootPath||'oscar/admin',rootPath:cfg.rootPath||'oscar/companies',appBaseUrl:normalizeAppUrl(cfg.appBaseUrl),trialDatabaseId:safe(cfg.trialDatabaseId||readMasterConfig()?.trialDatabaseId),savedAt:Date.now()};if(!master.database.databaseURL||!master.database.authToken)throw new Error('بيانات قاعدة الأم غير مكتملة.');localStorage.setItem(MASTER_KEY,wrapText(JSON.stringify(master)));return master}
  function readMasterConfig(){try{const raw=localStorage.getItem(MASTER_KEY);return raw?JSON.parse(unwrapText(raw)):null}catch(_){return null}}
  function clearMasterConfig(){localStorage.removeItem(MASTER_KEY)}

  function verificationMap(){try{return JSON.parse(localStorage.getItem(VERIFIED_KEY)||'{}')}catch(_){return{}}}
  function markVerified(payload,access){const all=verificationMap();all[payload.fileId]={fileId:payload.fileId,companyId:payload.companyId||payload.tenantId,companyKey:payload.companyKey||payload.activationKey,accountId:payload.account?.id||'',authVersion:payload.account?.authVersion||'',status:access?.status||'active',expiresAt:access?.endAt||payload.expiresAt||'',verifiedAt:Date.now()};localStorage.setItem(VERIFIED_KEY,JSON.stringify(all));return all[payload.fileId]}
  function cachedVerification(payload){const v=verificationMap()[payload?.fileId];if(!v)return null;if(v.companyId!==String(payload.companyId||payload.tenantId||''))return null;if(v.companyKey!==String(payload.companyKey||payload.activationKey||''))return null;if(v.accountId!==String(payload.account?.id||''))return null;if(String(v.authVersion||'')!==String(payload.account?.authVersion||''))return null;if(v.status!=='active')return null;if(v.expiresAt&&Date.now()>=new Date(v.expiresAt).getTime())return null;return v}

  function accountPath(payload){const companyId=encodeURIComponent(String(payload.companyId||payload.tenantId||''));const base=`oscar/companies/${companyId}`;if(payload.type==='company-manager')return `${base}/access/company`;return `${base}/d/employees/${encodeURIComponent(String(payload.account?.id||''))}`}
  function unwrapRecord(value){if(value&&typeof value==='object'&&Object.prototype.hasOwnProperty.call(value,'v'))return value.deleted?null:value.v;return value}
  function assertCompanyAccessStatus(access){
    const status=String(access?.status||'').trim().toLowerCase();
    if(status==='active')return true;
    if(['pending_payment','payment_review','pending'].includes(status))throw new Error('جاري معالجة دفعتك. سيتم تفعيل ملف الدخول فور اعتماد الدفعة من الإدارة.');
    if(['rejected_payment','rejected','payment_rejected'].includes(status))throw new Error('لم يتم اعتماد دفعتك. راجع بيانات التحويل أو تواصل مع الإدارة ثم أعد المحاولة.');
    throw new Error('تم إيقاف مفتاح الشركة من الإدارة العامة.');
  }
  async function verifyCompanyAccessRemote(payload){
    const db=payload?.database||readDatabaseAccess(payload?.companyId)||{},companyId=String(payload?.companyId||payload?.tenantId||'');
    if(!companyId||!db.databaseURL||!db.authToken)throw new Error('بيانات قاعدة الشركة غير متاحة.');
    const base=`oscar/companies/${encodeURIComponent(companyId)}`,access=unwrapRecord(await readExact(db,`${base}/access/company`,{ensureSchema:true}));
    if(!access)throw new Error('مفتاح الشركة غير مسجل في قاعدة الشركة.');
    if(String(access.companyKey||'').toUpperCase()!==String(payload.companyKey||payload.activationKey||'').toUpperCase())throw new Error('ملف التفعيل لا يطابق مفتاح الشركة.');
    assertCompanyAccessStatus(access);
    if(access.endAt&&Date.now()>=new Date(access.endAt).getTime())throw new Error('انتهت مدة تفعيل الشركة.');
    try{markVerified(payload,access)}catch(_){}
    return {access,online:true};
  }
  async function verifyPayloadRemote(payload){
    const db=payload.database||readDatabaseAccess(payload.companyId)||{},companyId=String(payload.companyId||payload.tenantId||'');if(!companyId||!db.databaseURL||!db.authToken)throw new Error('ملف التفعيل لا يحتوي على قاعدة شركة صالحة.');
    const base=`oscar/companies/${encodeURIComponent(companyId)}`,accessPath=`${base}/access/company`;let access=unwrapRecord(await readExact(db,accessPath,{ensureSchema:true}));
    if(!access)throw new Error('مفتاح الشركة غير مسجل في قاعدة الشركة.');if(String(access.companyKey||'').toUpperCase()!==String(payload.companyKey||payload.activationKey||'').toUpperCase())throw new Error('ملف التفعيل لا يطابق مفتاح الشركة.');assertCompanyAccessStatus(access);if(access.endAt&&Date.now()>=new Date(access.endAt).getTime())throw new Error('انتهت مدة تفعيل الشركة.');
    const account=payload.account||{};let verifiedAccount=null;
    if(payload.type==='company-manager'){
      let row=access.manager;if(!row||row.active===false)throw new Error('حساب مدير الشركة غير متاح.');if(String(row.id||'')!==String(account.id||''))throw new Error('ملف المدير لا يطابق الحساب المسجل.');
      const fileVersion=String(account.authVersion||''),currentVersion=String(row.authVersion||''),previousVersion=String(row.previousAuthVersion||''),pendingVersion=String(row.pendingAuthVersion||''),policyVersion=Number(row.authPolicyVersion||0);
      if(fileVersion===currentVersion){
        if(pendingVersion&&pendingVersion===currentVersion){const committed={...row,previousAuthVersion:'',pendingAuthVersion:'',pendingIssuedAt:'',authPolicyVersion:2,activatedAt:new Date().toISOString(),updatedAt:new Date().toISOString()},updatedAt=Date.now(),nextAccess={...access,manager:committed,updatedAt};await writeExact(db,accessPath,nextAccess,updatedAt,false);access=nextAccess;row=committed}
      }else if(previousVersion&&fileVersion===previousVersion&&pendingVersion){
        // الملف السابق يظل صالحاً مؤقتاً إلى أن يتم استعمال الملف الجديد لأول مرة بنجاح.
      }else if(policyVersion<2){
        const recovered={...row,...account,id:row.id||account.id,active:true,authVersion:fileVersion,previousAuthVersion:'',pendingAuthVersion:'',pendingIssuedAt:'',authPolicyVersion:2,recoveredAt:new Date().toISOString(),updatedAt:new Date().toISOString()},updatedAt=Date.now(),nextAccess={...access,manager:recovered,updatedAt};await writeExact(db,accessPath,nextAccess,updatedAt,false);access=nextAccess;row=recovered;
      }else throw new Error('تم إصدار ملف مدير أحدث. استخدم الملف الجديد.');
      verifiedAccount=row;
    }else{
      const row=unwrapRecord(await readExact(db,accountPath(payload)));if(!row)throw new Error('الحساب غير موجود في قاعدة الشركة أو لم تتم مزامنته بعد.');if(row.active===false)throw new Error('تم إيقاف هذا الحساب.');if(String(row.authVersion||'')!==String(account.authVersion||''))throw new Error('تم إصدار ملف دخول أحدث لهذا الحساب.');if(payload.type==='representative'&&String(row.role||'')!=='مندوب')throw new Error('الحساب لم يعد مندوباً.');if(payload.type==='branch-manager'&&String(row.role||'')!=='مدير فرع')throw new Error('حساب مدير الفرع غير متاح.');verifiedAccount=row;
    }
    markVerified(payload,access);return {access,online:true,account:clone(verifiedAccount||account)};
  }

  function isLogicalVerificationError(error){
    const msg=String(error?.message||error||'');
    return /مفتاح الشركة غير مسجل|لا يطابق|تم إيقاف|انتهت مدة|غير متاح|تم إصدار ملف|الحساب غير موجود|تم إيقاف هذا الحساب|لم يعد مندوباً|مدير الفرع غير متاح|جاري معالجة دفعتك|لم يتم اعتماد دفعتك/.test(msg);
  }
  function validatePayloadLocally(payload){
    if(!payload||payload.app!==APP_TAG)throw new Error('ملف التفعيل غير صالح.');
    const companyId=String(payload.companyId||payload.tenantId||'').trim();
    if(!companyId)throw new Error('ملف الشركة غير مكتمل.');
    if(payload.status&&payload.status!=='active'){
      const st=String(payload.status||'').toLowerCase();
      if(['pending_payment','payment_review','pending'].includes(st))throw new Error('جاري معالجة دفعتك. أول دخول بعد الموافقة يحتاج اتصالاً بالإنترنت.');
      if(['rejected_payment','rejected','payment_rejected'].includes(st))throw new Error('لم يتم اعتماد دفعتك. راجع بيانات التحويل أو تواصل مع الإدارة.');
      throw new Error('ملف الشركة غير فعال.');
    }
    if(payload.expiresAt&&Date.now()>=new Date(payload.expiresAt).getTime())throw new Error('انتهت مدة تفعيل الشركة.');
    const db=payload.database||readDatabaseAccess(companyId)||{};
    if(!db.databaseURL||!db.authToken)throw new Error('ملف التفعيل لا يحتوي على قاعدة شركة صالحة.');
    return {status:'active',endAt:payload.expiresAt||'',companyId,offlineLocal:true};
  }
  async function verifyPayload(payload,{allowOffline=true}={}){
    if(payload?.expiresAt&&Date.now()>=Date.parse(payload.expiresAt))throw Error('انتهت مدة تفعيل الشركة.');
    if(navigator.onLine!==false){
      try{return await verifyPayloadRemote(payload)}
      catch(error){
        if(isLogicalVerificationError(error))throw error;
        const cached=allowOffline?cachedVerification(payload):null;
        if(cached)return{access:cached,online:false,deferred:true,error:String(error?.message||error)};
        if(allowOffline){
          const access=validatePayloadLocally(payload);try{markVerified(payload,access)}catch(_){}
          return{access,online:false,deferred:true,provisional:true,error:String(error?.message||error)};
        }
        throw error;
      }
    }
    const cached=allowOffline?cachedVerification(payload):null;
    if(cached)return{access:cached,online:false,deferred:true};
    if(allowOffline){const access=validatePayloadLocally(payload);try{markVerified(payload,access)}catch(_){}return{access,online:false,deferred:true,provisional:true}}
    throw new Error('تعذر التحقق من ملف الدخول.');
  }
  function buildRolePayload(type,account,extra={}){const rt=readRuntime()||{};return{type,appBaseUrl:rt.appBaseUrl,activationKey:rt.companyKey||rt.activationKey,fileId:`${type}_${account?.id||Date.now()}_${account?.authVersion||''}`,companyId:rt.companyId,tenantId:rt.companyId,companyKey:rt.companyKey||rt.activationKey,companyName:rt.companyName||'الشركة',status:rt.status||'active',plan:rt.plan||'lifetime',expiresAt:rt.expiresAt||'',rootPath:rt.rootPath||'oscar/companies',database:readDatabaseAccess(rt.companyId)||rt.database||{},customerDatabase:clone(rt.customerDatabase||{}),trialProfile:clone(rt.trialProfile||{}),trialLimits:clone(rt.trialLimits||{}),ai:clone(rt.ai||{}),permissions:account?.permissions||[],account:clone(account),...extra}}
  async function prepareVerifiedRoleFile(type,account,fileName,copy=false){const payload=buildRolePayload(type,account);if(window.OscarCloudSync){const result=await window.OscarCloudSync.syncNow({manual:false,force:true});if(result?.remaining>0||result?.error)throw new Error('الحساب محفوظ محلياً لكن لم يصل إلى قاعدة الشركة بعد. شغّل المزامنة ثم أعد المحاولة.')}const verified=await verifyPayloadRemote(payload);payload.appBaseUrl=verified?.access?.appBaseUrl||payload.appBaseUrl;return copy==='link'?createActivationLink(payload):copy?copyActivationFile(payload):downloadActivationFile(payload,fileName)}

  async function prepareCompanyManagerFileRotation(fileName=''){
    const rt=readRuntime();if(!rt||rt.type!=='company-manager')throw new Error('هذه العملية متاحة لمدير الشركة فقط.');if(navigator.onLine===false)throw new Error('يجب الاتصال بالإنترنت لتغيير ملف المدير.');
    const db=readDatabaseAccess(rt.companyId)||rt.database||{},companyId=String(rt.companyId||rt.tenantId||'');if(!companyId||!db.databaseURL||!db.authToken)throw new Error('بيانات قاعدة الشركة غير متاحة.');
    const path=`oscar/companies/${encodeURIComponent(companyId)}/access/company`,access=unwrapRecord(await readExact(db,path,{ensureSchema:true}));if(!access)throw new Error('بيانات تفعيل الشركة غير موجودة.');
    const current=rt.account||{},remote=access.manager||{};if(String(remote.id||'')!==String(current.id||''))throw new Error('حساب المدير الحالي لا يطابق المدير المسجل.');
    const currentVersion=String(current.authVersion||''),remoteVersion=String(remote.authVersion||''),previousVersion=String(remote.previousAuthVersion||''),policyVersion=Number(remote.authPolicyVersion||0);
    if(policyVersion>=2&&currentVersion!==remoteVersion&&currentVersion!==previousVersion)throw new Error('هذا الملف لم يعد مخولاً بتغيير ملف المدير. ادخل بأحدث ملف مدير أولاً.');
    const authVersion='AUTH-'+(crypto.randomUUID?crypto.randomUUID():`${Date.now()}-${Math.random().toString(36).slice(2)}`),issuedAt=new Date().toISOString();
    const manager={...remote,...current,id:remote.id||current.id,active:true,authVersion,previousAuthVersion:currentVersion,pendingAuthVersion:authVersion,pendingIssuedAt:issuedAt,authPolicyVersion:2,updatedAt:issuedAt},updatedAt=Date.now(),nextAccess={...access,manager,updatedAt};
    const account={...manager,branchId:current.branchId||'BR-MAIN',permissions:Array.isArray(current.permissions)?current.permissions:[]},payload={type:'company-manager',activationKey:rt.companyKey||rt.activationKey,fileId:`manager_${account.id}_${authVersion}`,companyId,tenantId:companyId,companyKey:rt.companyKey||rt.activationKey,companyName:rt.companyName||access.companyName||'الشركة',status:access.status||rt.status||'active',plan:access.plan||rt.plan||'lifetime',expiresAt:access.endAt||rt.expiresAt||'',rootPath:rt.rootPath||'oscar/companies',database:db,customerDatabase:clone(rt.customerDatabase||{}),trialProfile:clone(rt.trialProfile||{}),trialLimits:clone(rt.trialLimits||{}),ai:clone(rt.ai||{}),account,permissions:account.permissions,app:APP_TAG};
    const prepared=await prepareActivationDownload(payload,fileName||`${rt.companyName||access.companyName||'الشركة'}-مدير-جديد.mzauth`);
    await writeExact(db,path,nextAccess,updatedAt,false);
    return{...prepared,authVersion,previousAuthVersion:currentVersion,companyId};
  }
  async function rotateCompanyManagerFile(fileName=''){const prepared=await prepareCompanyManagerFileRotation(fileName);triggerPreparedActivationDownload(prepared);return prepared}


  const LINK_DATABASE={
  databaseURL: 'libsql://tgggg-amanwaraa.aws-ap-northeast-1.turso.io',
  authToken: 'eyJhbGciOiJFZERTQSIsInR5cCI6IkpXVCJ9.eyJhIjoicnciLCJpYXQiOjE3OTA3NTI5MTUsImlkIjoiMDFhMGYxMzAtZTYwMS03NGExLThkOTktMDJkMWUwZjYxODQ4Iiwia2lkIjoiMGZxOHFxN2dNaDhyMGRXNEtuaWRuRzFrZDdUNFBrMXZkZDAxaGZNOVNtUSIsInJpZCI6IjQ0NWFmNzdiLTEwM2ItNGNkNC1hYTNmLWIxNTI3ZDUwZjcxYiJ9.gpLweb2Pwv6dpt7eYhVJOQpiOcf7eqszxDZSoD1N1RjDzrtPEIEJjh6xvveMOcrolHJMRRZ7_8TAGF8zthvQAg',
  table: 'oscar_rtdb',
};
  function normalizeAppUrl(value){const url=new URL(safe(value)||'https://www.cashtoop.com/');if(url.protocol!=='https:'&&!(url.protocol==='http:'&&['localhost','127.0.0.1'].includes(url.hostname)))throw Error('أدخل رابط HTTPS صالحاً للتطبيق.');url.search='';url.hash='';return url.href;}
  async function copyText(text){try{await navigator.clipboard.writeText(text);}catch{const field=document.createElement('textarea');field.value=text;field.style.cssText='position:fixed;top:0;opacity:0';document.body.appendChild(field);field.select();const ok=document.execCommand('copy');field.remove();if(!ok)throw Error('تعذر نسخ الرابط.');}return text;}
  async function loginLinkId(secret){return Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',enc.encode(secret))),n=>n.toString(16).padStart(2,'0')).join('');}
  async function createActivationLink(payload,baseUrl,{copy=true}={}){
    const made=await makeFile(payload);
    const url=new URL(normalizeAppUrl(baseUrl||payload.appBaseUrl||readRuntime()?.appBaseUrl));url.hash='code='+encodeURIComponent(made.opaque);
    if(copy)await copyText(url.href);return url.href;
  }
  async function resolveActivationLink(secret){
    if(!/^[A-Za-z0-9_-]{22}$/.test(secret))throw Error('رابط الدخول غير صالح.');
    const id=await loginLinkId(secret),cacheKey='ct_login_link_'+id;
    let row;
    if(navigator.onLine===false){try{row=JSON.parse(localStorage.getItem(cacheKey)||'null');}catch{}if(!row)throw Error('افتح رابط الدخول أول مرة مع اتصال بالإنترنت.');}
    else{row=await readExact(LINK_DATABASE,'oscar/login_links/'+id);if(!row?.sealed)throw Error('رابط الدخول غير موجود أو تم إلغاؤه.');}
    const opened=await openObject(row.sealed,secret);if(!opened?.opaque)throw Error('رابط الدخول تالف.');
    try{localStorage.setItem(cacheKey,JSON.stringify(row));}catch{}
    return opened.opaque;
  }
  async function writeInitialRecords(db,records){
    if(!Array.isArray(records)||!records.length)return;
    await ensure(db);
    const values=records.map(()=>'(?,?,0,?)').join(','),args=records.flatMap(r=>[normalizePath(r.path),JSON.stringify(r.value),Date.now()]);
    await pipeline(db,[{sql:`INSERT INTO ${tursoTable(db)}(path,payload,deleted,updated_at) VALUES ${values} ON CONFLICT(path) DO NOTHING`,args}]);
  }

  async function copyCurrentLoginLink(){const rt=readRuntime();if(!rt?.account)throw Error('سجّل الدخول أولاً.');const payload=buildRolePayload(rt.type||'employee',rt.account);const checked=await verifyPayloadRemote(payload);payload.account={...payload.account,...checked.account};payload.appBaseUrl=checked.access?.appBaseUrl||rt.appBaseUrl;payload.expiresAt=checked.access?.endAt||rt.expiresAt||'';payload.isTrialLink=!!rt.isTrialLink;return createActivationLink(payload);}
  window.OscarActivation={copyCurrentLoginLink,normalizeAppUrl,createActivationLink,resolveActivationLink,writeInitialRecords,version:3,copyActivationFile,makeFile,prepareActivationDownload,triggerPreparedActivationDownload,downloadActivationFile,primeActivationFile,readActivationFileText,parseActivationFile,activatePayload,readRuntime,clearRuntime,saveDatabaseAccess,readDatabaseAccess,saveMasterConfig,readMasterConfig,clearMasterConfig,sealObject,openObject,tursoDirect,verifyPayload,verifyPayloadRemote,verifyCompanyAccessRemote,cachedVerification,markVerified,buildRolePayload,prepareVerifiedRoleFile,prepareCompanyManagerFileRotation,rotateCompanyManagerFile,constants:{APP_TAG,RUNTIME_KEY,MASTER_KEY,LOCAL_DB_ACCESS_KEY,VERIFIED_KEY}};
})();
