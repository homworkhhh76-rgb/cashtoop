(function(){
'use strict';
const $=id=>document.getElementById(id);
const cfg=window.CASHTOP_TURSO?.config||{};
const base=String(cfg.databaseURL||'').replace(/\/+$/,'');
const isPathProxy=window.CASHTOP_TURSO?.backendMode==='turso-http-rtdb'||/__turso_rtdb__(?:$|\?)/i.test(base);
function transportUrl(url){if(!isPathProxy)return url;const raw=String(url||'');if(!raw.startsWith(base))return raw;let suffix=raw.slice(base.length).replace(/^\/+/,'');const q=suffix.indexOf('?');const pathPart=(q>=0?suffix.slice(0,q):suffix).replace(/\.json$/i,'');return `${base}?path=${encodeURIComponent(pathPart)}`}
const adminRoot=String(window.CASHTOP_TURSO?.adminRootPath||'cashTopExchange/cashTopAdmin').replace(/^\/+|\/+$/g,'');
const companyRoot=String(window.CASHTOP_TURSO?.rootPath||'cashTopExchange/cashTopPOS').replace(/^\/+|\/+$/g,'');
const supportRoot='cashTopExchange/cashTopSupport';
const SUPPORT_IMAGE_STORAGE=Object.freeze({storageZone:'amanwar1',pullHost:'amanwar1.b-cdn.net',accessKey:'bd094c93-3387-44e5-8ee02b4ff7c3-f22d-4060'});
const LOCAL_KEY='cashtop_admin_index_v15';
const LEGACY_LOCAL_KEY='cashtop_admin_index_v14';
const SESSION_KEY='cashtop_superadmin_session';
let state={superAdmin:null,companies:{},keyIndex:{},retiredKeys:{},updatedAt:0};
let pendingDeleteCompanyId='';
let preparedBackup=null;
let editingKey='';
let supportTickets=[];
let currentAdminView='companies';
const parse=(v,f)=>{try{return JSON.parse(v)??f}catch(_){return f}};
const rawGet=k=>Storage.prototype.getItem.call(localStorage,k);
const rawSet=(k,v)=>Storage.prototype.setItem.call(localStorage,k,String(v));
const sessionGet=k=>Storage.prototype.getItem.call(sessionStorage,k);
const sessionSet=(k,v)=>Storage.prototype.setItem.call(sessionStorage,k,String(v));
const sessionRemove=k=>Storage.prototype.removeItem.call(sessionStorage,k);
const normalizeKey=v=>String(v||'').trim().toUpperCase();
const normalizeLimit=value=>{
 if(value===null||value===undefined||value==='')return null;
 const n=Number(value);return Number.isFinite(n)?Math.max(0,Math.floor(n)):null
};
function normalizeCustomLimits(value){
 const v=value&&typeof value==='object'?value:{};
 const d=v.daily&&typeof v.daily==='object'?v.daily:{};
 const f=v.fixed&&typeof v.fixed==='object'?v.fixed:{};
 return {
  daily:{
   invoices:normalizeLimit(d.invoices),customers:normalizeLimit(d.customers),
   expenses:normalizeLimit(d.expenses),suppliers:normalizeLimit(d.suppliers)
  },
  fixed:{
   employees:normalizeLimit(f.employees),warehouses:normalizeLimit(f.warehouses),
   branches:normalizeLimit(f.branches),products:normalizeLimit(f.products)
  }
 };
}
function readCustomLimitsFromForm(){
 const read=id=>normalizeLimit($(id)?.value);
 return {daily:{invoices:read('limitInvoicesDaily'),customers:read('limitCustomersDaily'),expenses:read('limitExpensesDaily'),suppliers:read('limitSuppliersDaily')},
 fixed:{employees:read('limitEmployeesFixed'),warehouses:read('limitWarehousesFixed'),branches:read('limitBranchesFixed'),products:read('limitProductsFixed')}};
}
function fillCustomLimits(value){
 const v=normalizeCustomLimits(value);
 const set=(id,val)=>{const el=$(id);if(el)el.value=val==null?'':String(val)};
 set('limitInvoicesDaily',v.daily.invoices);set('limitCustomersDaily',v.daily.customers);
 set('limitExpensesDaily',v.daily.expenses);set('limitSuppliersDaily',v.daily.suppliers);
 set('limitEmployeesFixed',v.fixed.employees);set('limitWarehousesFixed',v.fixed.warehouses);
 set('limitBranchesFixed',v.fixed.branches);set('limitProductsFixed',v.fixed.products);
}
function decodeStoredValue(value,fallback=null){
 let parsed=value;
 for(let i=0;i<3&&typeof parsed==='string';i+=1){const decoded=parse(parsed,null);if(decoded===null)break;parsed=decoded}
 if(parsed&&typeof parsed==='object'&&!Array.isArray(parsed)&&Object.prototype.hasOwnProperty.call(parsed,'value')&&(parsed.valueEncoding||Object.prototype.hasOwnProperty.call(parsed,'deleted')||Object.prototype.hasOwnProperty.call(parsed,'updatedAt'))){
  if(parsed.deleted===true)return fallback;
  return decodeStoredValue(parsed.value,fallback);
 }
 return parsed==null?fallback:parsed;
}
function normalizeRecordArray(value,signatureKeys=[]){
 const parsed=decodeStoredValue(value,[]);
 if(Array.isArray(parsed))return parsed.filter(item=>item&&typeof item==='object'&&!Array.isArray(item));
 if(parsed&&typeof parsed==='object'){
  if(signatureKeys.some(key=>Object.prototype.hasOwnProperty.call(parsed,key)))return [parsed];
  return Object.entries(parsed).map(([key,item])=>{
   const decoded=decodeStoredValue(item,null);
   if(!decoded||typeof decoded!=='object'||Array.isArray(decoded))return null;
   return decoded.id==null&&!/^\d+$/.test(key)?{...decoded,id:key}:decoded;
  }).filter(Boolean);
 }
 return [];
}
function normalizePlainObject(value){const parsed=decodeStoredValue(value,{});return parsed&&typeof parsed==='object'&&!Array.isArray(parsed)?parsed:{}}
const safeSeg=v=>String(v||'').trim().replace(/[.#$\[\]\/]/g,'_');
function status(message,type='info'){const box=$('authStatus');if(!box)return;box.className=`status show ${type}`;box.textContent=message}
function toast(message,type='success'){
 let host=document.getElementById('adminToastHost');if(!host){host=document.createElement('div');host.id='adminToastHost';host.style.cssText='position:fixed;bottom:18px;right:18px;z-index:9999;display:grid;gap:8px;max-width:min(380px,calc(100vw - 36px))';document.body.appendChild(host)}
 const el=document.createElement('div');el.textContent=message;el.style.cssText=`padding:11px 14px;border-radius:8px;color:#fff;font:700 11px Cairo;box-shadow:0 8px 25px rgba(0,0,0,.18);background:${type==='error'?'#dd4b39':type==='warning'?'#f39c12':'#00a65a'}`;host.appendChild(el);setTimeout(()=>el.remove(),3600)
}
async function hashPassword(password,salt){const data=new TextEncoder().encode(`${salt}:${password}`);const digest=await crypto.subtle.digest('SHA-256',data);return [...new Uint8Array(digest)].map(b=>b.toString(16).padStart(2,'0')).join('')}
function makeSalt(){return crypto.randomUUID?crypto.randomUUID():`${Date.now()}_${Math.random()}`}
async function request(url,options={},timeout=18000){
 const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),timeout);
 try{
  const target=transportUrl(url);
  let sendOptions={...options,signal:controller.signal,cache:'no-store'};
  if(isPathProxy&&sendOptions.headers){
   const h=new Headers(sendOptions.headers);
   ['cache-control','pragma','if-match'].forEach(n=>h.delete(n));
   sendOptions={...sendOptions,headers:h};
  }
  const response=await fetch(target,sendOptions);
  if(!response.ok){
   const payload=await response.json().catch(()=>null);
   throw new Error(String(payload?.error?.message||payload?.error||`Turso API ${response.status}`));
  }
  return response;
 }finally{clearTimeout(timer)}
}
function adminUrl(path=''){return `${base}/${adminRoot}${path?'/'+path:''}.json`}
function companyUrl(companyId){return `${base}/${companyRoot}/${safeSeg(companyId)}.json`}
function supportUrl(path='tickets'){return `${base}/${supportRoot}${path?'/'+path:''}.json`}function companyDatasetUrl(companyId,key){return `${base}/${companyRoot}/${safeSeg(companyId)}/datasets/${safeSeg(key)}.json`}function companyMetaUrl(companyId){return `${base}/${companyRoot}/${safeSeg(companyId)}/meta.json`}
async function loadRemote(){if(!base)return null;try{const r=await request(adminUrl());return await r.json()}catch(e){console.warn('[ADMIN] load remote',e);return null}}
function loadLocal(){return parse(rawGet(LOCAL_KEY),null)||parse(rawGet(LEGACY_LOCAL_KEY),null)}
function normalizeState(value){const s=value&&typeof value==='object'?value:{};const companies=s.companies&&typeof s.companies==='object'?s.companies:{};const keyIndex=s.keyIndex&&typeof s.keyIndex==='object'?s.keyIndex:{};const retiredKeys=s.retiredKeys&&typeof s.retiredKeys==='object'?s.retiredKeys:{};Object.values(companies).forEach(c=>{c.backupImportEnabled=c.backupImportEnabled===true;c.plan=['classic','plus','pro','custom'].includes(String(c.plan||'').toLowerCase())?String(c.plan).toLowerCase():'pro';c.customLimits=normalizeCustomLimits(c.customLimits);c.tenantId=String(c.tenantId||c.companyId||`TENANT_${Date.now()}_${Math.random().toString(36).slice(2,8)}`);c.companyId=c.tenantId;if(c.key){const seg=safeSeg(normalizeKey(c.key));if(c.deleted===true||c.status==='deleted'){delete keyIndex[seg];retiredKeys[seg]={tenantId:c.tenantId,companyId:c.tenantId,key:normalizeKey(c.key),deletedAt:c.updatedAt||Date.now()};}else if(String(c.status||'active').toLowerCase()==='active'){keyIndex[seg]={...(keyIndex[seg]||{}),tenantId:c.tenantId,companyId:c.tenantId,key:normalizeKey(c.key)};delete retiredKeys[seg];}else{delete keyIndex[seg];delete retiredKeys[seg];}}});return {superAdmin:s.superAdmin||null,companies,keyIndex,retiredKeys,updatedAt:Number(s.updatedAt||0)}}
async function saveState(){state.updatedAt=Date.now();rawSet(LOCAL_KEY,JSON.stringify(state));if(base){try{await request(adminUrl(),{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify(state)});$('syncMode').textContent='Turso متزامن + تخزين محلي'}catch(e){$('syncMode').textContent='محلي — تعذر Turso';toast(`حُفظ محلياً، وتعذرت مزامنة الإدارة مع Turso: ${e.message}`,'warning')}}}
function sessionValid(){const s=parse(sessionGet(SESSION_KEY),null);return Boolean(s&&s.expiresAt>Date.now())}
function showApp(){$('authView').classList.add('hidden');$('appView').classList.remove('hidden');setAdminView('companies');render();refreshSupportTickets().catch(err=>console.warn('[ADMIN SUPPORT]',err))}
function setupAuthView(){const first=!state.superAdmin;$('confirmField').classList.toggle('hidden',!first);$('authSubtitle').textContent=first?'إنشاء أول حساب للمشرف العام':'دخول المشرف العام';$('authButton').innerHTML=first?'<i class="fa-solid fa-user-shield"></i> إنشاء حساب الإدارة':'<i class="fa-solid fa-shield-halved"></i> دخول الإدارة'}
async function handleAuth(e){e.preventDefault();const username=$('superUsername').value.trim(),password=$('superPassword').value;if(!state.superAdmin){const confirm=$('superPasswordConfirm').value;if(password!==confirm)return status('كلمتا المرور غير متطابقتين.','error');if(password.length<6)return status('كلمة المرور يجب أن تكون 6 أحرف على الأقل.','error');const salt=makeSalt();state.superAdmin={username,passwordHash:await hashPassword(password,salt),salt,createdAt:new Date().toISOString(),authVersion:Date.now()};await saveState();sessionSet(SESSION_KEY,JSON.stringify({username,expiresAt:Date.now()+8*60*60*1000}));showApp();return}const expected=await hashPassword(password,state.superAdmin.salt);if(String(username).toLowerCase()!==String(state.superAdmin.username).toLowerCase()||expected!==state.superAdmin.passwordHash)return status('بيانات المشرف العام غير صحيحة.','error');sessionSet(SESSION_KEY,JSON.stringify({username:state.superAdmin.username,expiresAt:Date.now()+8*60*60*1000}));showApp()}
function planNote(){
 const plan=$('plan').value;
 $('customLimitsPanel')?.classList.toggle('hidden',plan!=='custom');
 $('planDetails').innerHTML=plan==='classic'
  ?'<b>Classic:</b> 50 مبيعات/يوم، 5 مشتريات/يوم، 10 سندات/يوم، 100 منتج، موظفان، 50 عميلاً ومورداً، فرع ومستودع واحد. التصنيع وعروض المبيعات ودفتر الأستاذ ومجموعات العملاء والمناديب ونسخ الأقسام تتطلب ترقية.'
  :plan==='plus'
   ?'<b>Plus:</b> 200 منتج، فرعان، مستودعان لكل فرع، 3 موظفين لكل فرع، 200 فاتورة مبيعات/يوم لكل فرع، 10 مشتريات/يوم، 100 عميل جديد/يوم، 20 مصروف/يوم و50 مورداً، مع الميزات المتقدمة المتاحة للخطة.'
   :plan==='custom'
    ?'<b>مخصصة:</b> حدد الحدود اليومية والثابتة يدوياً من الحقول أدناه.'
    :'<b>Pro:</b> منتجات وفواتير ومستخدمون وفروع ومستودعات بلا حدود الخطة، مع التصنيع والعروض ودفتر الأستاذ ومجموعات العملاء والمناديب ونسخ الأقسام وبوابة العملاء.';
}
function calcExpiry(start=new Date()){const unit=$('durationUnit').value,q=Math.max(1,Number($('durationQuantity').value||1));if(unit==='unlimited')return '';const d=new Date(start);if(unit==='minute')d.setMinutes(d.getMinutes()+q);if(unit==='hour')d.setHours(d.getHours()+q);if(unit==='day')d.setDate(d.getDate()+q);if(unit==='month')d.setMonth(d.getMonth()+q);if(unit==='year')d.setFullYear(d.getFullYear()+q);return d.toISOString()}
function updateExpiryPreview(){const unit=$('durationUnit').value;$('durationQuantity').disabled=unit==='unlimited';const end=calcExpiry();$('expiryPreview').textContent=end?'تم تحديد مدة الاشتراك.':'مدة الاشتراك غير محدودة.'}
function generateKey(){return `CT-${Math.random().toString(36).slice(2,6).toUpperCase()}-${Date.now().toString(36).slice(-5).toUpperCase()}`}
function companyAccess(company){const tenantId=String(company.tenantId||company.companyId);return {tenantId,companyId:tenantId,companyKey:company.key,companyName:company.companyName,status:company.status,plan:company.plan,customLimits:normalizeCustomLimits(company.customLimits),startAt:company.startAt,endAt:company.endAt,durationUnit:company.durationUnit,durationQuantity:company.durationQuantity,backupImportEnabled:company.backupImportEnabled===true,authVersion:company.authVersion,updatedAt:Date.now(),manager:{id:`ADMIN_${tenantId}`,username:company.managerUsername,password:company.managerPassword,displayName:'مدير الشركة',role:'admin',active:company.status==='active',permissions:{},authVersion:company.authVersion}}}
function payload(value){return {value:JSON.stringify(value),valueEncoding:'local-storage-json-v1',deleted:false,updatedAt:Date.now(),revision:1,deviceId:'admin-console',page:'admin.html'}}
async function writeCompany(company){
 const tenantId=String(company.tenantId||company.companyId);company.tenantId=tenantId;company.companyId=tenantId;
 const accessPayload=payload(companyAccess(company));
 if(base){
  // اكتب بيانات الوصول أولاً ثم أعلن التغيير في meta. بهذه الطريقة لا يرى
  // جهاز آخر revision جديداً قبل اكتمال صف صلاحيات الشركة. PATCH ذري ولا يحتاج قراءة مسبقة.
  await request(companyDatasetUrl(tenantId,'cashtop_company_access'),{method:'PUT',headers:{'Content-Type':'application/json','Cache-Control':'no-cache, no-store'},body:JSON.stringify(accessPayload)});
  const announcedAt=Date.now();
  await request(companyMetaUrl(tenantId),{method:'PATCH',headers:{'Content-Type':'application/json','Cache-Control':'no-cache, no-store'},body:JSON.stringify({tenantId,companyId:tenantId,companyKey:company.key,companyName:company.companyName,schema:19,datasetStampSchema:1,datasetStamps:{cashtop_company_access:announcedAt},changedKeys:['cashtop_company_access'],updatedAt:announcedAt,managedBy:'cashTopAdmin'})});
 }
 let licenses=normalizeRecordArray(rawGet('cashtop_admin_licenses'),['key','tenantId','companyId','companyName','plan','status']);
 /* نعالج تلقائياً أي صيغة قديمة: Array أو Object أو قيمة قاعدة قديمة مغلفة، ثم نوحدها إلى Array قبل filter/find. */
 licenses=licenses.filter(x=>normalizeKey(x.key)!==normalizeKey(company.key)||String(x.tenantId||x.companyId||x.id)===tenantId);
 const li=licenses.findIndex(x=>String(x.tenantId||x.companyId||x.id)===tenantId);
 const license={id:tenantId,key:company.key,tenantId,companyId:tenantId,companyName:company.companyName,status:company.status,plan:company.plan,customLimits:normalizeCustomLimits(company.customLimits),startAt:company.startAt,endAt:company.endAt,durationUnit:company.durationUnit,durationQuantity:company.durationQuantity,backupImportEnabled:company.backupImportEnabled===true};
 if(li>=0)licenses[li]=license;else licenses.push(license);rawSet('cashtop_admin_licenses',JSON.stringify(licenses));
 let users=normalizeRecordArray(rawGet('cashtop_admin_users'),['username','companyKey','tenantId','companyId','role']);
 users=users.filter(x=>normalizeKey(x.companyKey)!==normalizeKey(company.key)||String(x.tenantId||x.companyId||'')===tenantId);
 const ui=users.findIndex(x=>String(x.tenantId||x.companyId||'')===tenantId&&x.role==='admin');
 const user={id:`ADMIN_${tenantId}`,companyKey:company.key,tenantId,companyId:tenantId,username:company.managerUsername,password:company.managerPassword,displayName:'مدير الشركة',role:'admin',active:company.status==='active'};
 if(ui>=0)users[ui]=user;else users.push(user);rawSet('cashtop_admin_users',JSON.stringify(users));
 const bindings=normalizePlainObject(rawGet('cashtop_tenant_bindings'));if(company.deleted===true||company.status!=='active')delete bindings[normalizeKey(company.key)];else bindings[normalizeKey(company.key)]=tenantId;rawSet('cashtop_tenant_bindings',JSON.stringify(bindings));
}
async function writeCompanyAccessOnly(company){
 const tenantId=String(company.tenantId||company.companyId);if(!base)return true;const accessPayload=payload(companyAccess(company));
 await request(companyDatasetUrl(tenantId,'cashtop_company_access'),{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify(accessPayload)},9000);
 const announcedAt=Date.now();
 await request(companyMetaUrl(tenantId),{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify({tenantId,companyId:tenantId,companyKey:company.key,companyName:company.companyName,schema:19,datasetStampSchema:1,datasetStamps:{cashtop_company_access:announcedAt},changedKeys:['cashtop_company_access'],updatedAt:announcedAt,managedBy:'cashTopAdmin'})},9000);
 return true;
}
async function mapConcurrent(items,limit,worker){let cursor=0;const results=[];async function run(){while(cursor<items.length){const i=cursor++;try{results[i]=await worker(items[i],i)}catch(e){results[i]=e}}}await Promise.all(Array.from({length:Math.min(limit,items.length||1)},run));return results}
async function saveCompany(e){
 e.preventDefault();const stateBeforeSave=JSON.stringify(state);const key=normalizeKey($('companyKey').value);if(!key)return toast('أدخل مفتاح الشركة.','error');
 const keySeg=safeSeg(key);
 const existingIndex=editingKey&&state.keyIndex[safeSeg(normalizeKey(editingKey))];
 const retired=state.retiredKeys?.[keySeg];
 const editingTenant=String(existingIndex&&(existingIndex.tenantId||existingIndex.companyId)||'');
 const retiredTenant=String(retired&&(retired.tenantId||retired.companyId)||'');
 // المفتاح المحذوف حذفاً عادياً يبقى مرتبطاً بنفس tenant حتى تعود نفس البيانات عند إضافته من جديد.
 // وإذا كان المستخدم يعدّل شركة أخرى فلا نسمح له باختطاف مفتاح له بيانات محفوظة؛
 // يُعاد إدخال المفتاح من نموذج شركة جديدة ليعود تلقائياً إلى شركته السابقة.
 if(editingTenant&&retiredTenant&&editingTenant!==retiredTenant)return toast('هذا المفتاح مرتبط ببيانات شركة محفوظة. ألغِ التعديل وأضف المفتاح من جديد لاستعادة نفس الشركة.','warning');
 const existingId=String(editingTenant||retiredTenant||'');
 const duplicateEntry=state.keyIndex[keySeg];const duplicate=duplicateEntry&&(duplicateEntry.tenantId||duplicateEntry.companyId);
 if(duplicate&&String(duplicate)!==existingId)return toast('مفتاح الشركة مستخدم لشركة أخرى نشطة.','error');
 const existing=existingId?state.companies[existingId]:null;const now=new Date();
 const existingEnd=existing?.endAt?new Date(existing.endAt):null;
 const renewingExpired=Boolean(existing&&$('status').value==='active'&&existingEnd&&Number.isFinite(existingEnd.getTime())&&existingEnd.getTime()<=now.getTime());
 const subscriptionStart=renewingExpired?now:(existing?.startAt?new Date(existing.startAt):now);
 const tenantId=String(existing?.tenantId||existing?.companyId||existingId||`TENANT_${Date.now()}_${crypto.randomUUID?crypto.randomUUID().slice(0,8):Math.random().toString(36).slice(2,10)}`);
 const company={tenantId,companyId:tenantId,companyName:$('companyName').value.trim(),key,managerUsername:$('managerUsername').value.trim(),managerPassword:$('managerPassword').value||existing?.managerPassword||'',plan:$('plan').value,customLimits:readCustomLimitsFromForm(),status:$('status').value,backupImportEnabled:$('backupImportEnabled').value==='true',durationUnit:$('durationUnit').value,durationQuantity:$('durationUnit').value==='unlimited'?null:Math.max(1,Number($('durationQuantity').value||1)),startAt:subscriptionStart.toISOString(),endAt:calcExpiry(subscriptionStart),authVersion:Date.now(),createdAt:existing?.createdAt||now.toISOString(),updatedAt:now.toISOString()};
 delete company.deleted;delete company.deletedAt;
 if(!company.companyName||!company.managerUsername||!company.managerPassword)return toast('أكمل اسم الشركة وبيانات مديرها.','error');
 if(editingKey&&normalizeKey(editingKey)!==key){const oldKey=normalizeKey(editingKey),oldSeg=safeSeg(oldKey);delete state.keyIndex[oldSeg];delete state.retiredKeys?.[oldSeg];const bindings=normalizePlainObject(rawGet('cashtop_tenant_bindings'));delete bindings[oldKey];rawSet('cashtop_tenant_bindings',JSON.stringify(bindings));}
 state.companies[tenantId]=company;if(company.status==='active')state.keyIndex[keySeg]={tenantId,companyId:tenantId,key,updatedAt:Date.now()};else delete state.keyIndex[keySeg];delete state.retiredKeys?.[keySeg];
 try{await writeCompany(company);await saveState();toast(retired?'تمت إعادة تفعيل المفتاح وربطه بنفس بيانات الشركة السابقة.':'تم حفظ الشركة. هذا المفتاح مرتبط بمسار بيانات مستقل بالكامل.');resetForm();render()}catch(err){state=normalizeState(parse(stateBeforeSave,{}));rawSet(LOCAL_KEY,JSON.stringify(state));render();toast(err.message||'تعذر حفظ الشركة.','error')}
}
function resetForm(){editingKey='';$('editingKey').value='';$('formTitle').textContent='إنشاء شركة ومفتاح جديد';$('companyForm').reset();$('companyKey').value=generateKey();$('durationUnit').value='month';$('durationQuantity').value=1;$('plan').value='classic';$('status').value='active';$('backupImportEnabled').value='false';fillCustomLimits({});$('cancelEdit').classList.add('hidden');planNote();updateExpiryPreview()}
function hydrateRetiredCompanyByKey(){if(editingKey)return;const key=normalizeKey($('companyKey').value),retired=state.retiredKeys?.[safeSeg(key)];if(!retired)return;const tenantId=String(retired.tenantId||retired.companyId||''),c=state.companies[tenantId];if(!c)return;$('companyName').value=c.companyName||'';$('managerUsername').value=c.managerUsername||'';$('managerPassword').value=c.managerPassword||'';$('plan').value=c.plan||'classic';fillCustomLimits(c.customLimits);$('status').value='active';$('backupImportEnabled').value=String(c.backupImportEnabled===true);$('durationUnit').value=c.durationUnit||'unlimited';$('durationQuantity').value=c.durationQuantity||1;planNote();updateExpiryPreview();toast('تم العثور على هذا المفتاح المحذوف. ستتم إعادة ربطه بنفس بيانات الشركة السابقة عند الحفظ.','info')}
function editCompany(id){const c=state.companies[id];if(!c)return;editingKey=c.key;$('editingKey').value=c.key;$('formTitle').textContent=`تعديل ${c.companyName}`;$('companyName').value=c.companyName;$('companyKey').value=c.key;$('managerUsername').value=c.managerUsername;$('managerPassword').value=c.managerPassword;$('plan').value=c.plan;fillCustomLimits(c.customLimits);$('status').value=c.status;$('backupImportEnabled').value=String(c.backupImportEnabled===true);$('durationUnit').value=c.durationUnit||'unlimited';$('durationQuantity').value=c.durationQuantity||1;$('cancelEdit').classList.remove('hidden');planNote();updateExpiryPreview();scrollTo({top:0,behavior:'smooth'})}
async function toggleCompany(id){
 const c=state.companies[id];if(!c)return;
 const seg=safeSeg(normalizeKey(c.key));const tenantId=String(c.tenantId||c.companyId);
 const stopping=c.status==='active';c.status=stopping?'stopped':'active';c.authVersion=Date.now();c.updatedAt=new Date().toISOString();
 if(stopping){delete state.keyIndex[seg];const bindings=normalizePlainObject(rawGet('cashtop_tenant_bindings'));delete bindings[normalizeKey(c.key)];rawSet('cashtop_tenant_bindings',JSON.stringify(bindings));}
 else{state.keyIndex[seg]={tenantId,companyId:tenantId,key:normalizeKey(c.key),updatedAt:Date.now()};delete state.retiredKeys?.[seg];}
 await writeCompany(c);await saveState();render();toast(c.status==='active'?'تم تفعيل المفتاح من جديد بنفس بيانات الشركة.':'تم إيقاف الاشتراك وحذف المفتاح من فهرس الدخول. سيتم تسجيل خروج الجلسات المفتوحة.','warning')
}
function deleteCompany(id){const c=state.companies[id];if(!c)return;pendingDeleteCompanyId=id;$('deleteAllCompanyData').checked=false;$('deleteCompanyMessage').innerHTML=`سيتم إيقاف مفتاح <b>${escapeHtml(c.key)}</b> لشركة <b>${escapeHtml(c.companyName)}</b>. إذا لم تحدد حذف جميع البيانات فستبقى بيانات الشركة محفوظة ويمكن إعادة نفس المفتاح لاحقاً لاستكمال العمل عليها.`;$('deleteCompanyModal').classList.add('show')}
function closeDeleteCompanyModal(){pendingDeleteCompanyId='';$('deleteCompanyModal').classList.remove('show');$('deleteAllCompanyData').checked=false}
function purgeLocalCompanyAdminRefs(company){const tenantId=String(company.tenantId||company.companyId),key=normalizeKey(company.key);let licenses=normalizeRecordArray(rawGet('cashtop_admin_licenses'),['key','tenantId','companyId','companyName','plan','status']);licenses=licenses.filter(x=>String(x.tenantId||x.companyId||x.id||'')!==tenantId&&normalizeKey(x.key)!==key);rawSet('cashtop_admin_licenses',JSON.stringify(licenses));let users=normalizeRecordArray(rawGet('cashtop_admin_users'),['username','companyKey','tenantId','companyId','role']);users=users.filter(x=>String(x.tenantId||x.companyId||'')!==tenantId&&normalizeKey(x.companyKey)!==key);rawSet('cashtop_admin_users',JSON.stringify(users));const bindings=normalizePlainObject(rawGet('cashtop_tenant_bindings'));delete bindings[key];rawSet('cashtop_tenant_bindings',JSON.stringify(bindings))}
async function confirmDeleteCompany(){const id=pendingDeleteCompanyId,c=state.companies[id];if(!c)return closeDeleteCompanyModal();const hardDelete=$('deleteAllCompanyData').checked===true;const btn=$('confirmDeleteCompany');btn.disabled=true;try{const key=normalizeKey(c.key),seg=safeSeg(key),tenantId=String(c.tenantId||c.companyId);if(hardDelete){if(base)await request(companyUrl(tenantId),{method:'DELETE',headers:{'Cache-Control':'no-cache, no-store'}},120000);purgeLocalCompanyAdminRefs(c);delete state.keyIndex[seg];delete state.retiredKeys?.[seg];delete state.companies[id];await saveState();closeDeleteCompanyModal();render();toast('تم حذف المفتاح وجميع بيانات الشركة نهائياً من قاعدة البيانات.','warning');return}c.status='deleted';c.deleted=true;c.deletedAt=new Date().toISOString();c.authVersion=Date.now();c.updatedAt=c.deletedAt;delete state.keyIndex[seg];state.retiredKeys=state.retiredKeys||{};state.retiredKeys[seg]={tenantId,companyId:tenantId,key,deletedAt:Date.now()};const bindings=normalizePlainObject(rawGet('cashtop_tenant_bindings'));delete bindings[key];rawSet('cashtop_tenant_bindings',JSON.stringify(bindings));await writeCompany(c);await saveState();closeDeleteCompanyModal();render();toast('تم إيقاف المفتاح مع الاحتفاظ بجميع بيانات الشركة. يمكن إعادة نفس المفتاح لاحقاً.','warning')}catch(err){toast(`تعذر تنفيذ الحذف: ${err.message||err}`,'error')}finally{btn.disabled=false}}

function formatBytes(bytes){const n=Number(bytes||0);if(n<1024)return `${n} B`;if(n<1024**2)return `${(n/1024).toFixed(2)} KB`;if(n<1024**3)return `${(n/1024**2).toFixed(2)} MB`;return `${(n/1024**3).toFixed(2)} GB`}
async function prepareFullBackup(){
 const btn=$('prepareBackupBtn');btn.disabled=true;btn.innerHTML='<i class="fa-solid fa-circle-notch fa-spin"></i> جاري استخراج جميع البيانات...';
 try{
  const companies={};const list=Object.values(state.companies||{});let done=0;
  for(const company of list){const id=String(company.tenantId||company.companyId);try{const r=await request(companyUrl(id),{},60000);companies[id]=await r.json()}catch(err){companies[id]={__backupError:String(err.message||err)}}done++;btn.innerHTML=`<i class="fa-solid fa-circle-notch fa-spin"></i> استخراج ${done}/${list.length}`}
  let supportTicketsBackup=null;try{const supportResponse=await request(supportUrl('tickets'),{},30000);supportTicketsBackup=await supportResponse.json().catch(()=>null)}catch(error){console.warn('[ADMIN BACKUP] support tickets skipped',error)}
  const packageData={format:'CASH_TOP_FULL_BACKUP',version:2,createdAt:new Date().toISOString(),adminState:state,companies,supportTickets:supportTicketsBackup};
  const text=JSON.stringify(packageData);preparedBackup={packageData,text,size:new Blob([text]).size};$('backupSize').textContent=formatBytes(preparedBackup.size);$('downloadBackupBtn').disabled=false;toast(`تم تجهيز نسخة شاملة بحجم ${formatBytes(preparedBackup.size)}.`)
 }catch(err){toast(`تعذر تجهيز النسخة: ${err.message||err}`,'error')}finally{btn.disabled=false;btn.innerHTML='<i class="fa-solid fa-magnifying-glass-chart"></i> استخراج البيانات وحساب الحجم'}
}
function downloadPreparedBackup(){if(!preparedBackup)return toast('قم باستخراج البيانات أولاً.','warning');const blob=new Blob([preparedBackup.text],{type:'application/json;charset=utf-8'});const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=`CashTop_All_Companies_Backup_${new Date().toISOString().replace(/[:.]/g,'-')}.json`;document.body.appendChild(a);a.click();setTimeout(()=>{URL.revokeObjectURL(a.href);a.remove()},500);}
function setRestoreProgress(percent,label=''){const p=Math.max(0,Math.min(100,Math.round(percent)));$('restoreProgress').classList.add('show');$('restoreProgressBar').style.width=`${p}%`;$('restoreProgressLabel').textContent=`${p}%${label?` — ${label}`:''}`}
async function restoreFullBackup(){
 const file=$('restoreBackupFile').files?.[0];if(!file)return toast('اختر ملف النسخة الاحتياطية أولاً.','warning');if(!confirm('سيتم استبدال بيانات الإدارة ومسارات الشركات الموجودة بالنسخة المختارة. هل تريد المتابعة؟'))return;
 const btn=$('restoreBackupBtn');btn.disabled=true;setRestoreProgress(1,'قراءة الملف');
 try{
  const data=JSON.parse(await file.text());if(data?.format!=='CASH_TOP_FULL_BACKUP'||!data.adminState||!data.companies)throw new Error('ملف النسخة غير صالح أو ليس نسخة شاملة من كاش توب.');
  const entries=Object.entries(data.companies);const hasSupport=Object.prototype.hasOwnProperty.call(data,'supportTickets');const total=entries.length+1+(hasSupport?1:0);let done=0;
  state=normalizeState(data.adminState);await request(adminUrl(),{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify(state)},60000);done++;setRestoreProgress((done/total)*100,'استعادة إعدادات الإدارة');
  for(const [id,value] of entries){await request(companyUrl(id),{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify(value)},120000);done++;setRestoreProgress((done/total)*100,`رفع الشركة ${done-1}/${entries.length}`)}
  if(hasSupport){await request(supportUrl('tickets'),{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify(data.supportTickets||{})},60000);done++;setRestoreProgress((done/total)*100,'استعادة رسائل الدعم')}
  rawSet(LOCAL_KEY,JSON.stringify(state));setRestoreProgress(100,'اكتملت الاستعادة بنجاح');render();refreshSupportTickets().catch(()=>null);toast('تم استيراد جميع بيانات الشركات والإدارة بنجاح.');
 }catch(err){toast(`فشل الاستيراد: ${err.message||err}`,'error')}finally{btn.disabled=false}
}
async function changeAdminPassword(e){e.preventDefault();const current=$('currentAdminPassword').value,next=$('newAdminPassword').value,confirmPass=$('confirmNewAdminPassword').value;if(next!==confirmPass)return toast('تأكيد كلمة المرور الجديدة غير مطابق.','error');if(next.length<6)return toast('كلمة المرور الجديدة يجب أن تكون 6 أحرف على الأقل.','error');const expected=await hashPassword(current,state.superAdmin.salt);if(expected!==state.superAdmin.passwordHash)return toast('كلمة المرور الحالية غير صحيحة.','error');const salt=makeSalt();state.superAdmin={...state.superAdmin,passwordHash:await hashPassword(next,salt),salt,authVersion:Date.now(),updatedAt:new Date().toISOString()};await saveState();$('changeAdminPasswordForm').reset();$('adminSettingsModal').classList.remove('show');toast('تم تغيير كلمة مرور المشرف العام ومزامنتها بنجاح.');}
async function copyKey(key){try{await navigator.clipboard.writeText(key)}catch(_){const input=document.createElement('input');input.value=key;document.body.appendChild(input);input.select();document.execCommand('copy');input.remove()}toast('تم نسخ المفتاح.')}
function fmt(v){return v?new Date(v).toLocaleString('ar-EG'):'غير محدود'}

function setAdminView(view='companies'){
 currentAdminView=view==='support'?'support':'companies';
 $('companiesAdminView')?.classList.toggle('hidden',currentAdminView!=='companies');
 $('supportAdminView')?.classList.toggle('hidden',currentAdminView!=='support');
 $('showCompaniesView')?.classList.toggle('active',currentAdminView==='companies');
 $('showSupportView')?.classList.toggle('active',currentAdminView==='support');
 if(currentAdminView==='support')refreshSupportTickets().catch(()=>null);
}
function safeHttpUrl(value){try{const url=new URL(String(value||''),location.href);return /^https?:$/i.test(url.protocol)?url.href:''}catch(_){return ''}}
function supportImagePath(image){
 const direct=String(image&&typeof image==='object'?image.path:'').trim().replace(/^\/+/, '');if(direct)return direct;
 const raw=String(typeof image==='string'?image:image?.url||'').trim();if(!raw)return '';
 try{const url=new URL(raw);if(String(url.hostname).toLowerCase()!==SUPPORT_IMAGE_STORAGE.pullHost.toLowerCase())return '';return url.pathname.split('/').filter(Boolean).map(part=>decodeURIComponent(part)).join('/')}catch(_){return ''}
}
async function deleteSupportImage(image){
 const path=supportImagePath(image);if(!path)return true;
 const endpoint=`https://storage.bunnycdn.com/${SUPPORT_IMAGE_STORAGE.storageZone}/${path.split('/').map(encodeURIComponent).join('/')}`;
 const response=await fetch(endpoint,{method:'DELETE',headers:{AccessKey:SUPPORT_IMAGE_STORAGE.accessKey},cache:'no-store'});
 if(response.ok||response.status===404)return true;
 throw new Error(`تعذر حذف صورة البلاغ (${response.status}).`);
}

function supportStatusLabel(status){return status==='resolved'?'تم الحل':status==='reviewing'?'قيد المراجعة':'جديد'}
async function loadSupportTickets(){
 if(!base)return [];
 const response=await request(supportUrl('tickets'),{},30000);
 const payload=await response.json().catch(()=>null);
 if(Array.isArray(payload))return payload.filter(Boolean);
 if(payload&&typeof payload==='object')return Object.entries(payload).map(([id,value])=>value&&typeof value==='object'?{id:value.id||id,...value}:null).filter(Boolean);
 return [];
}
function renderSupportTickets(){
 const host=$('supportTicketsHost');if(!host)return;
 const list=[...supportTickets].sort((a,b)=>new Date(b.createdAt||0)-new Date(a.createdAt||0));
 const unread=list.filter(t=>String(t.status||'new')==='new').length;
 if($('supportUnreadBadge'))$('supportUnreadBadge').textContent=`جديد: ${unread}`;if($('supportTabBadge'))$('supportTabBadge').textContent=String(unread);
 if(!list.length){host.innerHTML='<div class="note">لا توجد رسائل دعم حالياً.</div>';return}
 host.innerHTML=list.map(ticket=>{
  const id=String(ticket.id||'');const statusValue=['new','reviewing','resolved'].includes(String(ticket.status))?String(ticket.status):'new';
  const imgs=(Array.isArray(ticket.images)?ticket.images:[]).map(img=>{const url=safeHttpUrl(typeof img==='string'?img:img?.url);if(!url)return '';return `<a href="${escapeHtml(url)}" target="_blank" rel="noopener" title="فتح الصورة"><img src="${escapeHtml(url)}" alt="مرفق دعم" loading="lazy"></a>`}).join('');
  const identity=[ticket.companyName,ticket.companyKey,ticket.displayName||ticket.username].filter(Boolean).map(escapeHtml).join(' • ');
  return `<article class="support-ticket ${statusValue}"><div class="support-ticket-head"><div><div class="support-ticket-title">${escapeHtml(ticket.companyName||'شركة غير مسماة')}</div><div class="support-ticket-sub">${identity}<br>${escapeHtml(fmt(ticket.createdAt))} — ${escapeHtml(id)}</div></div><span class="support-status ${statusValue}">${supportStatusLabel(statusValue)}</span></div><div class="support-ticket-desc">${escapeHtml(ticket.description||'')}</div>${imgs?`<div class="support-images">${imgs}</div>`:''}<div class="support-ticket-actions"><button class="btn btn-warning" type="button" onclick="AdminPage.supportStatus('${encodeURIComponent(id)}','reviewing')"><i class="fa-solid fa-eye"></i> قيد المراجعة</button><button class="btn btn-success" type="button" onclick="AdminPage.supportStatus('${encodeURIComponent(id)}','resolved')"><i class="fa-solid fa-circle-check"></i> تم الحل</button><button class="btn btn-light" type="button" onclick="AdminPage.supportStatus('${encodeURIComponent(id)}','new')"><i class="fa-solid fa-rotate-left"></i> جديد</button><button class="btn btn-danger" type="button" onclick="AdminPage.supportDelete('${encodeURIComponent(id)}')"><i class="fa-solid fa-trash"></i> حذف البلاغ</button></div></article>`;
 }).join('');
}
async function refreshSupportTickets(){
 const button=$('refreshSupportBtn');if(button)button.disabled=true;
 try{supportTickets=await loadSupportTickets();renderSupportTickets()}catch(error){console.warn('[ADMIN SUPPORT LOAD]',error);const host=$('supportTicketsHost');if(host)host.innerHTML=`<div class="note" style="color:#b42318">تعذر تحميل رسائل الدعم: ${escapeHtml(error?.message||error)}</div>`}finally{if(button)button.disabled=false}
}
async function setSupportStatus(encodedId,statusValue){
 const id=decodeURIComponent(String(encodedId||''));if(!id)return;
 const status=['new','reviewing','resolved'].includes(statusValue)?statusValue:'new';
 try{await request(supportUrl(`tickets/${safeSeg(id)}`),{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify({status,updatedAt:new Date().toISOString()})},20000);const local=supportTickets.find(t=>String(t.id)===id);if(local){local.status=status;local.updatedAt=new Date().toISOString()}renderSupportTickets();toast('تم تحديث حالة بلاغ الدعم.')}catch(error){toast(`تعذر تحديث البلاغ: ${error?.message||error}`,'error')}
}
async function deleteSupportTicket(encodedId){
 const id=decodeURIComponent(String(encodedId||''));if(!id)return;
 const ticket=supportTickets.find(item=>String(item.id)===id);if(!ticket)return toast('البلاغ غير موجود.','warning');
 const images=Array.isArray(ticket.images)?ticket.images:[];
 if(!confirm(`سيتم حذف البلاغ نهائياً وحذف ${images.length} صورة مرفقة من مخزن الصور. هل تريد المتابعة؟`))return;
 try{
  for(const image of images)await deleteSupportImage(image);
  await request(supportUrl(`tickets/${safeSeg(id)}`),{method:'DELETE',headers:{'Cache-Control':'no-cache, no-store'}},30000);
  supportTickets=supportTickets.filter(item=>String(item.id)!==id);renderSupportTickets();toast('تم حذف البلاغ وصوره نهائياً.');
 }catch(error){console.error('[ADMIN SUPPORT DELETE]',error);toast(`تعذر حذف البلاغ بالكامل: ${error?.message||error}`,'error')}
}

function render(){
 const all=Object.values(state.companies||{}).filter(c=>!c.deleted);
 const query=String($('companySearch')?.value||'').trim().toLowerCase();
 const list=query?all.filter(c=>String(c.companyName||'').toLowerCase().includes(query)||String(c.key||'').toLowerCase().includes(query)):all;
 $('statAll').textContent=all.length;
 $('statActive').textContent=all.filter(c=>c.status==='active'&&(!c.endAt||new Date(c.endAt)>new Date())).length;
 if($('statClassic'))$('statClassic').textContent=all.filter(c=>c.plan==='classic').length;
 $('statPlus').textContent=all.filter(c=>c.plan==='plus').length;
 $('statPro').textContent=all.filter(c=>c.plan==='pro').length;
 if($('statCustom'))$('statCustom').textContent=all.filter(c=>c.plan==='custom').length;
 $('companiesBody').innerHTML=list.length?list.sort((a,b)=>new Date(b.createdAt)-new Date(a.createdAt)).map(c=>{
  const expired=c.endAt&&Date.now()>=new Date(c.endAt).getTime(),statusClass=expired?'expired':c.status==='active'?'active':'stopped',statusText=expired?'منتهي — قراءة فقط':c.status==='active'?'نشط':'موقوف',lock=c.backupImportEnabled===true?'<span class="badge active"><i class="fa-solid fa-lock-open"></i> مفتوح</span>':'<span class="badge stopped"><i class="fa-solid fa-lock"></i> مقفل</span>';
  const planLabel=c.plan==='classic'?'Classic':c.plan==='plus'?'Plus':c.plan==='custom'?'مخصصة':'Pro';
  return `<tr><td data-label="الشركة"><b>${escapeHtml(c.companyName)}</b></td><td data-label="المفتاح"><div class="key-cell"><code>${escapeHtml(c.key)}</code><button class="btn btn-light" type="button" title="نسخ المفتاح" onclick="AdminPage.copy(decodeURIComponent('${encodeURIComponent(c.key)}'))"><i class="fa-solid fa-copy"></i></button></div></td><td data-label="الخطة"><span class="badge ${c.plan}">${planLabel}</span></td><td data-label="الحالة"><span class="badge ${statusClass}">${statusText}</span></td><td data-label="المدير">${escapeHtml(c.managerUsername)}</td><td data-label="كلمة المرور"><div class="key-cell"><code class="company-password">••••••••</code><button class="btn btn-light" type="button" data-company-id="${escapeHtml(c.companyId)}" title="عرض كلمة المرور" aria-label="عرض كلمة المرور" onclick="AdminPage.togglePassword(this)"><i class="fa-solid fa-eye"></i></button></div></td><td data-label="استيراد النسخ">${lock}</td><td data-label="البدء">${fmt(c.startAt)}</td><td data-label="الانتهاء">${fmt(c.endAt)}</td><td data-label="الإجراءات"><div class="actions"><button class="btn btn-light" onclick="AdminPage.edit('${c.companyId}')"><i class="fa-solid fa-pen"></i></button><button class="btn ${c.status==='active'?'btn-warning':'btn-success'}" onclick="AdminPage.toggle('${c.companyId}')"><i class="fa-solid fa-power-off"></i></button><button class="btn btn-danger" onclick="AdminPage.remove('${c.companyId}')"><i class="fa-solid fa-trash"></i></button></div></td></tr>`;
 }).join(''):`<tr><td colspan="10" style="padding:25px;color:#64748b">${query?'لا توجد نتائج مطابقة للبحث.':'لا توجد شركات بعد.'}</td></tr>`;
}

function toggleCompanyPassword(button){
 const code=button?.closest('.key-cell')?.querySelector('.company-password');
 if(!code)return;
 const company=state.companies?.[String(button.dataset.companyId||'')];
 const password=String(company?.managerPassword||'');
 const revealed=button.dataset.revealed==='1';
 if(revealed){
  code.textContent='••••••••';
  button.dataset.revealed='0';
  button.title='عرض كلمة المرور';
  button.setAttribute('aria-label','عرض كلمة المرور');
  button.innerHTML='<i class="fa-solid fa-eye"></i>';
 }else{
  code.textContent=password||'—';
  button.dataset.revealed='1';
  button.title='إخفاء كلمة المرور';
  button.setAttribute('aria-label','إخفاء كلمة المرور');
  button.innerHTML='<i class="fa-solid fa-eye-slash"></i>';
 }
}

function escapeHtml(v){return String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
window.AdminPage={edit:editCompany,toggle:toggleCompany,remove:deleteCompany,copy:copyKey,togglePassword:toggleCompanyPassword,supportStatus:setSupportStatus,supportDelete:deleteSupportTicket,refreshSupport:refreshSupportTickets,view:setAdminView};
window.addEventListener('DOMContentLoaded',async()=>{state=normalizeState(await loadRemote()||loadLocal());rawSet(LOCAL_KEY,JSON.stringify(state));setupAuthView();if(sessionValid())showApp();$('authForm').addEventListener('submit',handleAuth);$('companyForm').addEventListener('submit',saveCompany);$('generateKey').addEventListener('click',()=>{$('companyKey').value=generateKey()});$('companyKey').addEventListener('change',hydrateRetiredCompanyByKey);$('companySearch')?.addEventListener('input',render);$('showCompaniesView')?.addEventListener('click',()=>setAdminView('companies'));$('showSupportView')?.addEventListener('click',()=>setAdminView('support'));$('refreshSupportBtn')?.addEventListener('click',refreshSupportTickets);$('plan').addEventListener('change',planNote);$('durationUnit').addEventListener('change',updateExpiryPreview);$('durationQuantity').addEventListener('input',updateExpiryPreview);$('cancelEdit').addEventListener('click',resetForm);$('logoutBtn').addEventListener('click',()=>{sessionRemove(SESSION_KEY);location.reload()});$('confirmDeleteCompany').addEventListener('click',confirmDeleteCompany);$('cancelDeleteCompany').addEventListener('click',closeDeleteCompanyModal);$('deleteCompanyModal').addEventListener('click',e=>{if(e.target===$('deleteCompanyModal'))closeDeleteCompanyModal()});$('adminSettingsBtn').addEventListener('click',()=>$('adminSettingsModal').classList.add('show'));$('closeAdminSettings').addEventListener('click',()=>$('adminSettingsModal').classList.remove('show'));$('adminSettingsModal').addEventListener('click',e=>{if(e.target===$('adminSettingsModal'))$('adminSettingsModal').classList.remove('show')});$('changeAdminPasswordForm').addEventListener('submit',changeAdminPassword);$('prepareBackupBtn').addEventListener('click',prepareFullBackup);$('downloadBackupBtn').addEventListener('click',downloadPreparedBackup);$('restoreBackupBtn').addEventListener('click',restoreFullBackup);resetForm();render()});
})();
